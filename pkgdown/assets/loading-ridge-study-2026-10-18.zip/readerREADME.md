# Loading-ridge study supplement

This archive supplements the loading-ridge sensitivity article. The study
crossed three families (grouped-binomial probit, replicated Gaussian and
replicated Poisson), two unit counts (`n` = 100 or 400), and two loading
multipliers (`strength` = 0.5 or 2), for 12 native-Laplace conditions. Each
condition had 500 simulated datasets and was fit at four loading-prior scales
(`tau` = 1, 2, 4 or `Inf`; `Inf` is unpenalised). The fixed-truth design and
simulated input generator are in `runner/generate.R`; that file generates data
and does not fit models or access a network.

The archive contains aggregate result tables, data-generation code and
provenance. It does not include raw fitted model objects, individual fit
outputs, the compiled model binary, or the source tarball. The generator alone
cannot reproduce the full fitting study.

- `recovery.csv` reports condition-by-scale attempt counts, fit and Hessian
  counts, covariance summaries, and their Monte Carlo uncertainty. Its keys
  are `family`, `n` (units), `strength` (loading multiplier), and `tau`
  (loading-prior standard deviation).
- `effects.csv` reports trait-effect estimates and interval availability,
  coverage summaries, and Monte Carlo uncertainty by condition, scale, and
  target.
- `paired-vs-Inf.csv` reports paired comparisons with matched and dropped
  counts and Monte Carlo uncertainty.
- `unique-recovery-summary.csv` reports recovery summaries for the unique
  covariance component.
- `independent-audit-counts.csv` records counts for the independent checks of
  retained study results.

The fit source is pinned to commit
`161abe09a417cad88b51c018a09a930d964ee3de`; the exported study record is from
commit `609fe5685c4825c26337d4392052b2fe0a4d29ff`. The recorded runtime was
R 4.6.1 and TMB 1.9.25. `PROVENANCE.json` preserves the source and binary
checksums and documents which materials are absent. `SHA256SUMS` verifies every
other file in this archive.
